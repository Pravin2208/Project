package com.healthcare.controllers;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.healthcare.beans.AddTest;
import com.healthcare.beans.CustomerRegistration;
import com.healthcare.beans.CustomerTechnician;
import com.healthcare.beans.TechnicianRegistration;
import com.healthcare.service.HealthCareService;

@Controller
public class CustomerController {
	@Autowired
	HealthCareService healthCareService;

	@RequestMapping(value = "/viewCustomer", method = RequestMethod.GET)
	public ModelAndView viewcustomer(HttpServletRequest request, HttpServletResponse response,
			@ModelAttribute("CustomerRegistration") CustomerRegistration customerRegistration) {
		List<CustomerRegistration> list = healthCareService.getCustomers();
		ModelAndView map = new ModelAndView("viewCustomer");
		map.addObject("list", list);
		return map;

	}

	@RequestMapping(value = "/bookTechnician", method = RequestMethod.GET)
	public ModelAndView booktechnician(HttpServletRequest request, HttpServletResponse response,
			@ModelAttribute("TechnicianRegistration") TechnicianRegistration technicianRegistration) {
		List<TechnicianRegistration> list = healthCareService.getbookedTechnicians();
		ModelAndView map = new ModelAndView("bookTechnician");
		map.addObject("list", list);
		return map;
	}

	////////////Adding Techician///////////////////
	  @RequestMapping("/customertechnician") 
	  public String showtech(Model m) {
	  m.addAttribute("command", new CustomerTechnician()); 
	  return "customertechnician"; }
	  
	  
	  @RequestMapping(value = "/customerTechicianAllocation", method =RequestMethod.POST) 
	  public String save(@ModelAttribute("customerTechnician") CustomerTechnician customerTechnician) 
	  { healthCareService.saveCustoTechnician(customerTechnician); 
	  return "redirect:/assignedTechnician";
	  }
	  
	  @RequestMapping(value = "/assignedTechnician", method = RequestMethod.GET)
		public ModelAndView viewassignedTechnician(HttpServletRequest request, HttpServletResponse response,
				@ModelAttribute("CustomerRegistration") CustomerRegistration customerRegistration) {
			List<CustomerRegistration> list = healthCareService.getassignedTechnician();
			ModelAndView map = new ModelAndView("assignedTechnician");
			map.addObject("list", list);
			return map;

		}
	  
	  
	  
	  
	 

}