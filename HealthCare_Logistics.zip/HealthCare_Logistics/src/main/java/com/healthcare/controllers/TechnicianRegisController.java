package com.healthcare.controllers;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;
import com.healthcare.beans.TechnicianRegistration;
import com.healthcare.service.HealthCareService;

@Controller
public class TechnicianRegisController {
  @Autowired
  public HealthCareService healthCareService;
  @RequestMapping(value = "/technicianRegistration", method = RequestMethod.GET)
  public ModelAndView showRegister(HttpServletRequest request, HttpServletResponse response) {
    ModelAndView mav = new ModelAndView("technicianRegistration");
    mav.addObject("technicianRegistration", new TechnicianRegistration());
    return mav;
  }
  @RequestMapping(value = "/registerProcessTechnician", method = RequestMethod.POST)
  public ModelAndView addUser(HttpServletRequest request, HttpServletResponse response,
  @ModelAttribute("TechnicianRegistration") TechnicianRegistration technicianRegistration) {
	  healthCareService.registerTechnician(technicianRegistration);
  return new ModelAndView("welcome", "firstname", technicianRegistration.getFirstname());
  }
}