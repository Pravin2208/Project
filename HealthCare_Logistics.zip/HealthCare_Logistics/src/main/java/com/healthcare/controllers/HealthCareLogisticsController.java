package com.healthcare.controllers;

public class HealthCareLogisticsController {

}
