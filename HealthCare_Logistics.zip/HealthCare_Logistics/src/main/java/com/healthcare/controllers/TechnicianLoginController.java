package com.healthcare.controllers;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;


import com.healthcare.beans.TechnicianLogin;
import com.healthcare.beans.TechnicianRegistration;
import com.healthcare.service.HealthCareService;

@Controller
public class TechnicianLoginController {
	
	@Autowired
	  HealthCareService healthCareService;

	
	@RequestMapping(value = "/technicianLogin", method = RequestMethod.GET)
	  public ModelAndView showLogin(HttpServletRequest request, HttpServletResponse response) {
	    ModelAndView mav = new ModelAndView("technicianLogin");
	    mav.addObject("technicianLogin", new TechnicianLogin());
	    return mav;
	  }
	  @RequestMapping(value = "/loginTechnicianProcess", method = RequestMethod.POST)
	  public ModelAndView loginProcess(HttpServletRequest request, HttpServletResponse response,
	  @ModelAttribute("technicianLogin") TechnicianLogin technicianLogin) {
	    ModelAndView mav = null;
	    TechnicianRegistration technicianRegistration = healthCareService.validateTechnician(technicianLogin);
	    if (null != technicianRegistration) {
	    mav = new ModelAndView("technicianHome");
	    mav.addObject("firstname", technicianRegistration.getFirstname());
	    } else {
	    mav = new ModelAndView("technicianLogin");
	    mav.addObject("message", "Username or Password is wrong!!");
	    }
	    return mav;
	  }

}
