package com.healthcare.controllers;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.healthcare.beans.AddTest;
import com.healthcare.beans.AddTestCost;
import com.healthcare.beans.CustomerRegistration;
import com.healthcare.beans.TechnicianRegistration;
import com.healthcare.service.HealthCareService;

@Controller
public class TechnicianController {
	@Autowired
	HealthCareService healthCareService;
	
	
	

	/* It provides list of products in model object */
	@RequestMapping("/viewTechnician")
	public String viewtechnician(Model m) {
		List<TechnicianRegistration> list = healthCareService.getTechnicians();
		m.addAttribute("list", list);
		return "viewTechnician";
	}
	
	
	@RequestMapping("/addTestCost")
	public String showform(Model m) {
		m.addAttribute("command", new AddTestCost());
		return "addTestCost";
	}

	
	@RequestMapping(value = "/saveTestCost", method = RequestMethod.POST)
	public String save(@ModelAttribute("addtests") AddTestCost addtestcost) {
		healthCareService.saveTestCost(addtestcost);
		return "redirect:/viewTestCost";
	}
	
	@RequestMapping(value = "/viewTestCost", method = RequestMethod.GET)
	public ModelAndView viewtestcost(HttpServletRequest request, HttpServletResponse response,
			@ModelAttribute("AddTestCost") AddTestCost addTestcost) {
		List<AddTestCost> list = healthCareService.getTestCost();
		ModelAndView map = new ModelAndView("viewTestCost");
		map.addObject("list", list);
		return map;
	}
	
	 @RequestMapping(value = "/assignedCustomers", method = RequestMethod.GET)
		public ModelAndView viewassignedCustomer(HttpServletRequest request, HttpServletResponse response,
				@ModelAttribute("TechnicianRegistration") CustomerRegistration customerRegistration) {
			List<CustomerRegistration> list = healthCareService.getassignedCustomer();
			ModelAndView map = new ModelAndView("assignedCustomers");
			map.addObject("list", list);
			return map;

		}

	
}