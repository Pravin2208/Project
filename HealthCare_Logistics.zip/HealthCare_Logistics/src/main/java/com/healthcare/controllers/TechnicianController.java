package com.healthcare.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.healthcare.beans.TechnicianRegistration;
import com.healthcare.service.HealthCareService;

@Controller
public class TechnicianController {
	@Autowired
	HealthCareService healthCareService;
	
	
	

	/* It provides list of products in model object */
	@RequestMapping("/viewTechnician")
	public String viewtechnician(Model m) {
		List<TechnicianRegistration> list = healthCareService.getTechnicians();
		m.addAttribute("list", list);
		return "viewTechnician";
	}

	
}