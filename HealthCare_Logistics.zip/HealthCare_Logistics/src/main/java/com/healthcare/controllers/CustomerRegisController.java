package com.healthcare.controllers;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.healthcare.beans.CustomerRegistration;
import com.healthcare.service.HealthCareService;

@Controller
public class CustomerRegisController {
  @Autowired
  public HealthCareService healthCareService;
  @RequestMapping(value = "/customerRegistration", method = RequestMethod.GET)
  public ModelAndView showRegister(HttpServletRequest request, HttpServletResponse response) {
    ModelAndView mav = new ModelAndView("customerRegistration");
    mav.addObject("customerRegistration", new CustomerRegistration());
    return mav;
  }
  @RequestMapping(value = "/registerProcessCustomer", method = RequestMethod.POST)
  public ModelAndView addUser(HttpServletRequest request, HttpServletResponse response,
  @ModelAttribute("CustomerRegistration") CustomerRegistration customerRegistration) {
	  healthCareService.registerCustomer(customerRegistration);
  return new ModelAndView("welcome", "firstname", customerRegistration.getFirstname());
  }
}