package com.healthcare.controllers;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.healthcare.beans.ManagerLogin;
import com.healthcare.beans.ManagerRegistartion;
import com.healthcare.service.HealthCareService;

@Controller
public class ManagerLoginController {
	
	@Autowired
	  HealthCareService healthCareService;

	
	@RequestMapping(value = "/managerLogin", method = RequestMethod.GET)
	  public ModelAndView showLogin(HttpServletRequest request, HttpServletResponse response) {
	    ModelAndView mav = new ModelAndView("managerLogin");
	    mav.addObject("managerLogin", new ManagerLogin());
	    return mav;
	  }
	  @RequestMapping(value = "/loginProcess", method = RequestMethod.POST)
	  public ModelAndView loginProcess(HttpServletRequest request, HttpServletResponse response,
	  @ModelAttribute("managerLogin") ManagerLogin managerlogin) {
	    ModelAndView mav = null;
	    ManagerRegistartion managerRegistartion = healthCareService.validateManager(managerlogin);
	    if (null != managerRegistartion) {
	    mav = new ModelAndView("managerHome");
	    mav.addObject("firstname", managerRegistartion.getFirstname());
	    } else {
	    mav = new ModelAndView("managerLogin");
	    mav.addObject("message", "Username or Password is wrong!!");
	    }
	    return mav;
	  }

}
