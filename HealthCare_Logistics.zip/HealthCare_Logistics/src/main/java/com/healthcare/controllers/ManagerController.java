package com.healthcare.controllers;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.healthcare.beans.AddTest;
import com.healthcare.service.HealthCareService;



@Controller
public class ManagerController {
	@Autowired
	HealthCareService healthCareService;
	
	@RequestMapping("/addTests")
	public String showform(Model m) {
		m.addAttribute("command", new AddTest());
		return "addTests";
	}

	
	@RequestMapping(value = "/saveTest", method = RequestMethod.POST)
	public String save(@ModelAttribute("addtests") AddTest addtest) {
		healthCareService.saveTest(addtest);
		return "redirect:/viewTest";
	}
	
	
	
	@RequestMapping(value = "/viewTest", method = RequestMethod.GET)
	public ModelAndView viewtest(HttpServletRequest request, HttpServletResponse response,
			@ModelAttribute("AddTest") AddTest addTest) {
		List<AddTest> list = healthCareService.getTest();
		ModelAndView map = new ModelAndView("viewTest");
		map.addObject("list", list);
		return map;
	}
	

	
}