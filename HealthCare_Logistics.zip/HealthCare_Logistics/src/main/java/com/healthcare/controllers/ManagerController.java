package com.healthcare.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.healthcare.beans.AddTest;
import com.healthcare.beans.CustomerRegistration;
import com.healthcare.service.HealthCareService;



@Controller
public class ManagerController {
	@Autowired
	HealthCareService healthCareService;
	
	@RequestMapping("/addTests")
	public String showform(Model m) {
		m.addAttribute("command", new AddTest());
		return "addTests";
	}

	
	@RequestMapping(value = "/saveTest", method = RequestMethod.POST)
	public String save(@ModelAttribute("addtests") AddTest addtest) {
		healthCareService.saveTest(addtest);
		return "redirect:/viewTest";
	}
	
	
	
	@RequestMapping("/viewTest")
	public String viewtest(Model m) {
		List<AddTest> list = healthCareService.getTest();
		m.addAttribute("list", list);
		return "viewTest";
	}
	

	
}