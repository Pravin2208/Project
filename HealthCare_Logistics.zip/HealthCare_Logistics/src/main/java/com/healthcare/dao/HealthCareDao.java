package com.healthcare.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

import com.healthcare.beans.AddTest;
import com.healthcare.beans.CustomerLogin;
import com.healthcare.beans.CustomerRegistration;
import com.healthcare.beans.ManagerLogin;
import com.healthcare.beans.ManagerRegistartion;
import com.healthcare.beans.TechnicianLogin;
import com.healthcare.beans.TechnicianRegistration;
import com.healthcare.service.HealthCareService;


public class HealthCareDao {
	@Autowired
	  HealthCareService healthCareService;
	
	  
	JdbcTemplate template;
	  
	public void setTemplate(JdbcTemplate template) {    
	    this.template = template;    
	}
	

	

	  public void registerManager(ManagerRegistartion managerRegistartion) {

	    String sql = "insert into manager values(?,?,?,?,?,?,?)";

	    template.update(sql, new Object[] { managerRegistartion.getUsername(), managerRegistartion.getPassword(), managerRegistartion.getFirstname(),
	    		managerRegistartion.getLastname(), managerRegistartion.getEmail(), managerRegistartion.getAddress(), managerRegistartion.getPhone() });
	  }

	  public ManagerRegistartion validateManager(ManagerLogin managerLogin) {

	    String sql = "select * from manager where username='" + managerLogin.getUsername() + "' and password='" + managerLogin.getPassword()
	        + "'";

	    List<ManagerRegistartion> manager = template.query(sql, new ManagerMapper());

	    return manager.size() > 0 ? manager.get(0) : null;
	  }
	  
	  class ManagerMapper implements RowMapper<ManagerRegistartion> {

		  public ManagerRegistartion mapRow(ResultSet rs, int arg1) throws SQLException {
			  ManagerRegistartion managerRegistartion = new ManagerRegistartion();

			  managerRegistartion.setUsername(rs.getString("username"));
			  managerRegistartion.setPassword(rs.getString("password"));
			  managerRegistartion.setFirstname(rs.getString("firstname"));
			  managerRegistartion.setLastname(rs.getString("lastname"));
			  managerRegistartion.setEmail(rs.getString("email"));
			  managerRegistartion.setAddress(rs.getString("address"));
			  managerRegistartion.setPhone(rs.getString("phone"));

		    return managerRegistartion;
		  }

	}

	public CustomerRegistration validateCustomer(CustomerLogin customerLogin) {
		  String sql = "select * from customer where username='" + customerLogin.getUsername() + "' and password='" + customerLogin.getPassword()
	        + "'";

	    List<CustomerRegistration> customer = template.query(sql, new CustomerMapper());

	    return customer.size() > 0 ? customer.get(0) : null;
	}


	 class CustomerMapper implements RowMapper<CustomerRegistration> {

		  public CustomerRegistration mapRow(ResultSet rs, int arg1) throws SQLException {
			  CustomerRegistration customerRegistration = new CustomerRegistration();

			  customerRegistration.setUsername(rs.getString("username"));
			  customerRegistration.setPassword(rs.getString("password"));
			  customerRegistration.setFirstname(rs.getString("firstname"));
			  customerRegistration.setLastname(rs.getString("lastname"));
			  customerRegistration.setEmail(rs.getString("email"));
			  customerRegistration.setAddress(rs.getString("address"));
			  customerRegistration.setPhone(rs.getString("phone"));

		    return customerRegistration;
		  }

	}

	public void registerCustomer(CustomerRegistration customerRegistration) {
		 String sql = "insert into customer values(?,?,?,?,?,?,?)";

		 template.update(sql, new Object[] { customerRegistration.getUsername(), customerRegistration.getPassword(), customerRegistration.getFirstname(),
				 customerRegistration.getLastname(), customerRegistration.getEmail(), customerRegistration.getAddress(), customerRegistration.getPhone() });
	}




	public TechnicianRegistration validateTechnician(TechnicianLogin technicianLogin) {
		 String sql = "select * from technician where username='" + technicianLogin.getUsername() + "' and password='" + technicianLogin.getPassword()
	        + "'";

	    List<TechnicianRegistration> technician = template.query(sql, new TechnicianMapper());

	    return technician.size() > 0 ? technician.get(0) : null;
	}
	
	class TechnicianMapper implements RowMapper<TechnicianRegistration> {

		  public TechnicianRegistration mapRow(ResultSet rs, int arg1) throws SQLException {
			  TechnicianRegistration technicianRegistration = new TechnicianRegistration();

			  technicianRegistration.setUsername(rs.getString("username"));
			  technicianRegistration.setPassword(rs.getString("password"));
			  technicianRegistration.setFirstname(rs.getString("firstname"));
			  technicianRegistration.setLastname(rs.getString("lastname"));
			  technicianRegistration.setEmail(rs.getString("email"));
			  technicianRegistration.setLocation(rs.getString("location"));
			  technicianRegistration.setTime(rs.getString("time"));
			  technicianRegistration.setPhone(rs.getString("phone"));

		    return technicianRegistration;
		  }

	}

	public void registerTechnician(TechnicianRegistration technicianRegistration) {
		 String sql = "insert into technician values(?,?,?,?,?,?,?,?)";

		 template.update(sql, new Object[] { technicianRegistration.getUsername(), technicianRegistration.getPassword(), technicianRegistration.getFirstname(),
				 technicianRegistration.getLastname(), technicianRegistration.getEmail(), technicianRegistration.getLocation(), technicianRegistration.getTime(), technicianRegistration.getPhone() });
	}




	public List<TechnicianRegistration> getTechnicians() {
		 return template.query("select * from technician",new RowMapper<TechnicianRegistration>(){    
		        public TechnicianRegistration mapRow(ResultSet rs, int row) throws SQLException {    
		        	TechnicianRegistration e=new TechnicianRegistration();    
		            e.setFirstname(rs.getString(3));  
		            e.setLastname(rs.getString(4));
		            e.setEmail(rs.getString(5));
		            e.setLocation(rs.getString(6));
		            e.setTime(rs.getString(7));
		            e.setPhone(rs.getString(8));
		            return e;    
		        }    
		    });   
	}




	public List<CustomerRegistration> getCustomers() {
		 return template.query("select * from customer",new RowMapper<CustomerRegistration>(){    
		        public CustomerRegistration mapRow(ResultSet rs, int row) throws SQLException {    
		        	CustomerRegistration e=new CustomerRegistration();    
		            e.setFirstname(rs.getString(3));  
		            e.setLastname(rs.getString(4));
		            e.setEmail(rs.getString(5));
		            e.setAddress(rs.getString(6));
		            e.setPhone(rs.getString(7));
		            return e;    
		        }    
		    });   
	}




	public int saveTest(AddTest addtest) {
		String sql="insert into addtest(testname,description) values('"+addtest.getTestname()+"','"+addtest.getDescription()+"')";    
	    System.out.println("Save Query=== "+sql);
	    return template.update(sql);  
		
	}




	public List<AddTest> getTest() {
		return template.query("select * from addtest",new RowMapper<AddTest>(){    
	        public AddTest mapRow(ResultSet rs, int row) throws SQLException {    
	        	AddTest e=new AddTest();    
	            e.setTestname(rs.getString(1));  
	            e.setDescription(rs.getString(2));
	            return e;    
	        }    
	    });   
	}




	public List<TechnicianRegistration> getbookedTechnicians() {
		 return template.query("select * from technician",new RowMapper<TechnicianRegistration>(){    
		        public TechnicianRegistration mapRow(ResultSet rs, int row) throws SQLException {    
		        	TechnicianRegistration e=new TechnicianRegistration();    
		            e.setFirstname(rs.getString(3));  
		            e.setLastname(rs.getString(4));
		            e.setEmail(rs.getString(5));
		            e.setLocation(rs.getString(6));
		            e.setTime(rs.getString(7));
		            e.setPhone(rs.getString(8));
		            return e;    
		        }    
		    });   
	}










}

