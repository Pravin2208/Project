package com.healthcare.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.healthcare.beans.AddTest;
import com.healthcare.beans.AddTestCost;
import com.healthcare.beans.CustomerLogin;
import com.healthcare.beans.CustomerRegistration;
import com.healthcare.beans.CustomerTechnician;
import com.healthcare.beans.ManagerLogin;
import com.healthcare.beans.ManagerRegistartion;
import com.healthcare.beans.TechnicianLogin;
import com.healthcare.beans.TechnicianRegistration;
import com.healthcare.dao.HealthCareDao;

@Service
public class HealthCareServiceImpl implements HealthCareService{

	@Autowired
	private HealthCareDao healthCareDao; 	
	
	@Transactional
	public void registerManager(ManagerRegistartion managerRegistartion) {
		healthCareDao.registerManager(managerRegistartion);
		
	}

	@Transactional
	public ManagerRegistartion validateManager(ManagerLogin managerLogin) {
		return healthCareDao.validateManager(managerLogin);
	}

	public CustomerRegistration validateCustomer(CustomerLogin customerLogin) {
		return healthCareDao.validateCustomer(customerLogin);
	}

	public void registerCustomer(CustomerRegistration customerRegistration) {
		healthCareDao.registerCustomer(customerRegistration);
	  }

	public TechnicianRegistration validateTechnician(TechnicianLogin technicianLogin) {
		return healthCareDao.validateTechnician(technicianLogin);
	}

	public void registerTechnician(TechnicianRegistration technicianRegistration) {
		healthCareDao.registerTechnician(technicianRegistration);
		
	}

	public List<TechnicianRegistration> getTechnicians() {
		return healthCareDao.getTechnicians();
	}

	public List<CustomerRegistration> getCustomers() {
		return healthCareDao.getCustomers();
	}

	public void saveTest(AddTest addtest) {
		healthCareDao.saveTest(addtest);
		
	}

	public List<AddTest> getTest() {
		return healthCareDao.getTest();
	}

	public List<TechnicianRegistration> getbookedTechnicians() {
		return healthCareDao.getbookedTechnicians();
	}

	public void saveCustoTechnician(CustomerTechnician customerTechnician) {
		healthCareDao.saveCustoTechnician(customerTechnician);
		
	}

	public List<CustomerRegistration> getassignedTechnician() {
		return healthCareDao.getassignedTechnician();
	}

	public void saveTestCost(AddTestCost addtestcost) {
		healthCareDao.saveTestCost(addtestcost);
		
	}

	public List<AddTestCost> getTestCost() {
		return healthCareDao.getTestCost();
	}

	public List<CustomerRegistration> getassignedCustomer() {
		return healthCareDao.getassignedCustomer();
	}

	
	}

	
	
	

	
	
	
	
	
	
	
	


