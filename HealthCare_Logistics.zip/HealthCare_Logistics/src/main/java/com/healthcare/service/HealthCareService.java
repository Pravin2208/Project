package com.healthcare.service;

import java.util.List;

import com.healthcare.beans.AddTest;
import com.healthcare.beans.AddTestCost;
import com.healthcare.beans.CustomerLogin;
import com.healthcare.beans.CustomerRegistration;
import com.healthcare.beans.CustomerTechnician;
import com.healthcare.beans.ManagerLogin;
import com.healthcare.beans.ManagerRegistartion;
import com.healthcare.beans.TechnicianLogin;
import com.healthcare.beans.TechnicianRegistration;

public interface HealthCareService {
	
	void registerManager(ManagerRegistartion managerRegistartion);

	ManagerRegistartion validateManager(ManagerLogin managerLogin);

	CustomerRegistration validateCustomer(CustomerLogin customerLogin);

	void registerCustomer(CustomerRegistration customerRegistration);

	TechnicianRegistration validateTechnician(TechnicianLogin technicianLogin);

	void registerTechnician(TechnicianRegistration technicianRegistration);

	List<TechnicianRegistration> getTechnicians();

	List<CustomerRegistration> getCustomers();

	void saveTest(AddTest addtest);

	List<AddTest> getTest();

	List<TechnicianRegistration> getbookedTechnicians();

	void saveCustoTechnician(CustomerTechnician customerTechnician);

	List<CustomerRegistration> getassignedTechnician();

	void saveTestCost(AddTestCost addtestcost);

	List<AddTestCost> getTestCost();


	 List<CustomerRegistration> getassignedCustomer(); 

	

}
