package com.healthcare.beans;

public class AddTestCost {
	String techuid;
	String testname;
	String price;
	public String getTechuid() {
		return techuid;
	}
	public void setTechuid(String techuid) {
		this.techuid = techuid;
	}
	public String getTestname() {
		return testname;
	}
	public void setTestname(String testname) {
		this.testname = testname;
	}
	public String getPrice() {
		return price;
	}
	public void setPrice(String price) {
		this.price = price;
	}

}
